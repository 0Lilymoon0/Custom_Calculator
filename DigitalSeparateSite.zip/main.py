#Ask the user how many hours they spend online daily on average.
online_hours_daily = float(input ("How many hours on average would you say you spend online daily? "))
#Print the new line character for neatness.
print("\n")
#Ask the user how many hours they spend offline daily on average.
offline_hours_daily = float(input("How many hours on average would you say you spend offline daily? "))
#Print the new line character for neatness.
print("\n")
#Multiply both the daily online and offline hours by 365 to turn the daily hours into yearly hours.
online_hours_yearly = (online_hours_daily * 365)
offline_hours_yearly = (offline_hours_daily * 365)
#Print out the yearly hours on average the user spends online and offline. 
print(f"On average, you would be spending {online_hours_yearly} hours online per year, and {offline_hours_yearly} hours offline per year.")